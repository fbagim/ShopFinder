﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ShopFinder.Model;

namespace ShopFinder.Pages
{
    public class Login : PageModel
    {
        private readonly ShopFinder.Data.ShopFinderContext _context;

        public Login(ShopFinder.Data.ShopFinderContext context)
        {
            _context = context;
        }

        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public string Msg { get; set; }

        public void OnGet()
        {
        }

        //public IActionResult OnPost()
        //{
        //    Shop shop = _context.Shop.Find(m => m == Username);
        //    if (Username.Equals("abc") && Password.Equals("123"))
        //    {
        //        HttpContext.Session.SetString("username", Username);
        //        return RedirectToPage("Welcome");
        //    }
        //    else
        //    {
        //        Msg = "Invalid";
        //        return Page();
        //    }
        //}



        public async Task<IActionResult> OnPost()
        {
            if (Username == null || Password == null)
            {
                Msg = "Please Enter UserID and Password";
                return Page();
            }
            Shop shop = await _context.Shop.FirstOrDefaultAsync(m => m.UserID == Username);
            if (shop == null)
            {
                Msg = "Invalid UserID";
                return Page();

            }
            else
            {
                if (shop.UserID == Username && shop.Password == Password)
                {
                    HttpContext.Session.SetString("username", Username);
                    return RedirectToPage("ShopPages/Index");
                }
            }
            Msg = "Please Enter UserID and Password";
            return Page();
        }
    }
}