﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ShopFinder.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customer",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ContactName = table.Column<string>(nullable: true),
                    ContactNo = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    Address1 = table.Column<string>(nullable: true),
                    Address2 = table.Column<string>(nullable: true),
                    Province = table.Column<string>(nullable: true),
                    Distric = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Province",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Province", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Request",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerID = table.Column<int>(nullable: false),
                    ShopID = table.Column<int>(nullable: false),
                    BuyingItems = table.Column<string>(nullable: true),
                    IsCreditCardRequiredOnDlivery = table.Column<bool>(nullable: false),
                    GPSLocation = table.Column<string>(nullable: true),
                    RequestSendOn = table.Column<DateTime>(nullable: false),
                    RequestAcceptedOn = table.Column<DateTime>(nullable: false),
                    RequestStatus = table.Column<DateTime>(nullable: false),
                    Updated = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Request", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "ShopStatus",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ShopID = table.Column<int>(nullable: false),
                    IsOpen = table.Column<bool>(nullable: false),
                    IsDiliveryAvilabel = table.Column<bool>(nullable: false),
                    IsCreditCardAccept = table.Column<bool>(nullable: false),
                    IsCreditCardAcceptOnDeliveryLocation = table.Column<bool>(nullable: false),
                    OpenTime = table.Column<DateTime>(nullable: false),
                    ClosedTime = table.Column<DateTime>(nullable: false),
                    Updated = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ShopStatus", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Distric",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProvinceID = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Distric", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Distric_Province_ProvinceID",
                        column: x => x.ProvinceID,
                        principalTable: "Province",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Shop",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ShopName = table.Column<string>(nullable: true),
                    UserID = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    ShopStatusID = table.Column<int>(nullable: false),
                    ShopStatusID1 = table.Column<int>(nullable: true),
                    ConatctPerson = table.Column<string>(nullable: true),
                    Address1 = table.Column<string>(nullable: true),
                    Address2 = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    GPSLocation = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    ContactNo1 = table.Column<int>(nullable: false),
                    ContactNo2 = table.Column<int>(nullable: false),
                    ContactNo3 = table.Column<int>(nullable: false),
                    Updated = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shop", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Shop_ShopStatus_ShopStatusID1",
                        column: x => x.ShopStatusID1,
                        principalTable: "ShopStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "City",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DistricID = table.Column<int>(nullable: false),
                    ProvinceID = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_City", x => x.ID);
                    table.ForeignKey(
                        name: "FK_City_Distric_DistricID",
                        column: x => x.DistricID,
                        principalTable: "Distric",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_City_DistricID",
                table: "City",
                column: "DistricID");

            migrationBuilder.CreateIndex(
                name: "IX_Distric_ProvinceID",
                table: "Distric",
                column: "ProvinceID");

            migrationBuilder.CreateIndex(
                name: "IX_Shop_ShopStatusID1",
                table: "Shop",
                column: "ShopStatusID1");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "City");

            migrationBuilder.DropTable(
                name: "Customer");

            migrationBuilder.DropTable(
                name: "Request");

            migrationBuilder.DropTable(
                name: "Shop");

            migrationBuilder.DropTable(
                name: "Distric");

            migrationBuilder.DropTable(
                name: "ShopStatus");

            migrationBuilder.DropTable(
                name: "Province");
        }
    }
}
