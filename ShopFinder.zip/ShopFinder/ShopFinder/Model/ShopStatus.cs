﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ShopFinder.Model
{
    public class ShopStatus
    {
        public int ID
        {
            get; set;
        }
        public int ShopID
        {
            get; set;
        }
       
        public bool IsOpen
        {
            get; set;
        }
        public bool IsDiliveryAvilabel
        {
            get; set;
        }
        public bool IsCreditCardAccept
        {
            get; set;
        }
        public bool IsCreditCardAcceptOnDeliveryLocation
        {
            get; set;
        }
        [Display(Name = "OpenTime")]
        [DataType(DataType.Time)]
        public DateTime OpenTime
        {
            get; set;
        }
        [Display(Name = "ClosedTime")]
        [DataType(DataType.Time)]
        public DateTime ClosedTime
        {
            get; set;
        }
        [Display(Name = "Updated")]
        [DataType(DataType.Date)]
        public DateTime Updated
        {
            get; set;
        }
    }
}
