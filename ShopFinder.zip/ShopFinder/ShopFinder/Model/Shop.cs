﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ShopFinder.Model
{
    public class Shop { 
    
        public int ID
        {
            get; set;
        }
        public String ShopName
        {
            get; set;
        }
        public String UserID
        {
            get; set;
        }
        public String Password
        {
            get; set;
        }

        public int ShopStatusID
        {
            get; set;
        }
        public ShopStatus ShopStatus
        {
            get; set;
        }

        public String ConatctPerson
        {
            get; set;
        }

        public String Address1
        {
            get; set;
        }
        public String Address2
        {
            get; set;
        }
        public String City
        {
            get; set;
        }
        public String GPSLocation
        {
            get; set;
        }
        public String Email
        {
            get; set;
        }
        public int ContactNo1
        {
            get; set;
        }
        public int ContactNo2
        {
            get; set;
        }
        public int ContactNo3
        {
            get; set;
        }

     
        [Display(Name = "Updated")]
        [DataType(DataType.Date)]
        public DateTime Updated { get; set; }
    }
}
